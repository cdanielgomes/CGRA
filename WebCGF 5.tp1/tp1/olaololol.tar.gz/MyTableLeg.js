/**
 * MyTableLeg
 * @param gl {WebGLRenderingContext}
 * @constructor
 */


 class MyTableLeg extends CGFObject
 {
    constructor() {
        super();
        this.leg = new MyUnitCubeQuad(this.scene);
    }

    display(){
        
    }
    
 }