/**
 * MyTable
 * @param gl {WebGLRenderingContext}
 * @constructor
 */


 class MyTable extends CGFObject
 {
    constructor() {
        super();
        this.cube = new MyUnitCubeQuad(this.scene);
    }
    
    display(){
        this.scene.scale(5,0.3,3);
        cube.display();
    }
 }